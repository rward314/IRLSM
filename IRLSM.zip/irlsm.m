function X = irlsm(Y, PF, r, niter, tol, DISP)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT :
% Y     :  The partially revealed matrix.
%       :     
%
% PF    :  The full matrix of revealed observations: 
%       :  PF_{ij} = 1 if entry (i,j) is revealed, 0 otherwise
%
% r     :  The rank to be used for reconstruction. Use [] for default r=sum(PF(:))/(2*length(Y))
% niter :  The max. no. of iterations. Use [] to use default (1000).
% tol   :  Stop iterations if norm(Y - X, 'fro' )/norm(Y) < tol, where
%        - Y_{ij} = 1 if M_{ij} is revealed and zero otherwise, 
%        - |E| is the size of the revealed set.				
%        - Use [] to use the default (1e-9)
% DISP  : 0 or 1, depending on whether one wants output printed to screen 
%
% OUTPUT :
% X      : Reconstructed matrix
%
% Date : 12 February, 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(length(DISP)==0)
     DISP = 1;
end

if(nargin==2)
[m n] = size(Y);
tol = 1e-9;
niter = 1000;

if DISP
fprintf(1, 'Using default rank ... \n');
end

r=sum(PF(:))/(2*length(Y));

if DISP
fprintf(1, 'Using rank : %d\n', r);
end

elseif(nargin==3 || nargin==4 || nargin==5 || nargin==6)

[m,n] = size(Y);

if(nargin==3)
    tol = 1e-9;
    niter=1000;
elseif(nargin==4)
    tol=1e-9;
else
   if(length(tol)==0)
       tol = 1e-9;
   end
   
   if(length(r)==0)
       if DISP
       fprintf(1, 'Using default rank ... \n');
       end
       
       r=sum(PF(:))/(2*length(Y));
       
       if DISP
       fprintf(1, 'Using rank : %d\n', r);
       end
   end
   
   if(length(niter)==0)
       niter=1000;
   end
   
end
else
    fprintf(1, 'Arguments not of correct form');
    return;
end
       

v0 = zeros(m,1);
q=0;  
Keigs = r;

eps_old = 1;
eps = 1;
eps_new = .5;

clear('options');

options.issym = 1;
options.issreal = 1;
options.disp = 0;

starttime = cputime;

%starting point for the weight
W = ones(m,m);

U = W(:,1:Keigs);
sigma = ones(Keigs,1);
seps = sigma - eps*ones(Keigs,1);

X = Y;

%compute eigenvalue decomposition of X*X'
[U,D] = eigs(sparse(X*X'),Keigs+1,'lm',options);


d = diag(D);  
d = sqrt(abs(d));

[d,index] = sort(d,'descend');
U = U(:,index);

%first Keigs eigenvalues
sigma = d(1:Keigs);

%pivot eigenvalue
SigmaK1 = d(Keigs+1);

U = U(:,1:Keigs);
    
seps = sigma - eps*ones(Keigs,1);

w = zeros(n*Keigs,1); 

if DISP
fprintf(1,'Iteration\tEpsilon\t\tTime\n');
end


SId = speye(n);

%start algorithm
while( abs(eps_old - eps_new) > tol && q < niter)
    
    %iteration number
    q = q + 1;
    
    
    %Minimize columnwise the Frobenius norm;
    %solve least squares problems using Sherman-Morrison-Woodbury formula
    
    sinv = seps.^(-1);
    Z = U'*Y;
    eUU = eps^(-1)*U*spdiags(seps,0,Keigs,Keigs)*U';
    
    %Build up the sparse matrix containing the corresponding equation
    %for each column update
	
	V = IRLS (U, PF, sinv, eps, Z);  % <<<-------c implementation

	X = (eUU + eye(m))*(Y-V);
    
    %compute largest Keigs eigenvalues and eigenvectors

    v0(1:Keigs+1) = d(1:Keigs+1);
    
    options.v0 = v0;    
    options.disp = 0;
    
    [U,D] = eigs(sparse(X*X'),Keigs+1,'lm',options);
    
    d = diag(D);  
    d = sqrt(abs(d));
    
    
    [d,index] = sort(d,'descend');
    
    U = U(:,index);
    
    sigma = d(1:Keigs);
    SigmaK1 = d(Keigs+1);
   
    
    U = U(:,1:Keigs);
    
    seps = sigma - eps*ones(Keigs,1);
    
    if(mod(q,20)==0)
        eps_old = eps_new;
        eps_new = eps;
        if DISP
        fprintf(1,'%d\t\t%0.10f\t%g\n',q, eps, cputime - starttime);
        end
    end
           
    %update epsilon
    if(q<30)
        eps = .9*eps;
    else
        eps = min(eps,.5*SigmaK1);
    end
    
   
       
end

if DISP
fprintf(1,'%d\t\t%0.10f\t%g\n',q, eps, cputime - starttime);
end

end

