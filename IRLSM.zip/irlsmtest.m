% Sample code to test the iterative reweighted least squares
% algorithm for low-rank matrix recovery

DISP = 1;

if DISP
fprintf(1, 'Generating Matrix...\n');
end

m = 200;      %matrix row dimension
n = 200;      %matrix column dimension
r = 5;        %sparsity level
tol = 1e-9;   
k = .2*m*n;   %total number of measurements

sig = 0;       %noise level
niter = 500;  %max number of iterations in reconstruction alg.


U = randn(m,r);
V = randn(n,r);
Sig = eye(r);

M = U*Sig*V' + sig*randn(m,n);
M = M/norm(M,'fro');

%create sparse mask of partially revealed entries
ii = randperm(m*n);
iik = ii(1:k);
P = sparse(m,n);
P(iik) = 1;
PF = full(P);

%Y is the partially revealed matrix
Y = sparse(M.*P);

%Implement iterative reweighted least squares algorithm

%irlsm(Y, PF, r)
%irlsm(Y, PF, r, niter)
%irlsm(Y, PF, r, niter, tol)
X = irlsm(Y, PF, r, niter, tol, DISP);

if DISP
fprintf(1, 'Relative error: %e\n',norm(M-X,'fro')/norm(M,'fro'));
end


