IRLS-M: Iteratively reweighed least squares recovery for matrix completion

COPYRIGHT � 2011 
Massimo Fornasier <massimo.fornasier@oeaw.ac.at>, RICAM Linz
Holger Rauhut <rauhut@hcm.uni-bonn.de>, University of Bonn
Rachel Ward <ward@cims.nyu.dot.edu>, New York University  
Stephan Worm <Stephan Worm <stephanworm@gmx.de>, University of Bonn

Based on the algorithm described in
M. Fornasier, H. Rauhut, R. Ward, Low rank matrix recovery via iteratively reweighted least squares, 
Preprint, 2010.

IRLS-M is free software.
  You can redistribute it and/or modify it under the terms of the GNU General
  Public License as published by the Free Software Foundation; either version
  2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License in the file COPYING for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Comments are welcome.
  This is the first version of the toolbox and may not be as robust or well
  documented as it should be. Please keep track of bugs or missing/  
 confusing instructions and report them to us.

------------------------------------


Files included:

irlsmtest.m    This is the code that the user should run to test 
               the IRLS reconstruction algorithm 

irlsm.m        The main reconstruction algorithm  

irls.c         C code used in irlsm.m  


---------------------
A compiled version for Mac is provided in IRLS.mexmaci, but depending on the mac-version
a new compilation maybe necessary. For all other operating systems compilation 
is necessary in any case.

To compile the C code enter in the Matlab command window

>> mex irls.c

This requires that the file irls.c is in the current directory, and that a C compiler is properly installed.
(We are not able to provide instructions on how to install a C compiler on your operating system. Please ask
your system administrator.)

