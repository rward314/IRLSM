/*
 ============================================================================
 Name        : IRLS.c
 Author      : Stephan Worm
 Version     :
 Copyright   :
 Description : IRLS for matrix recovery
 ============================================================================
 */

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include "mex.h"

#define NULL 0

double **matrix_smartinit(int n, int m) {

	int i;
	double **ret;

	if (!(ret = malloc(n*m*sizeof(double) + n*sizeof(double*)))) return NULL;
	for(i=0; i<n; i++) {
		ret[i] = (double *)(ret + n) + m*i;
	}
	return ret;
}

double float_abs(double a) {
    
    if(a>0) return a;
    return -a;
}

void print_matrix(double **A, int m, int n) {
    int i,j;
    for(i=0; i<m; i++) {
        for(j=0;j<n;j++) {
            printf("%f\t",A[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    return;
}

void print_matrix_fabs(double **A, int m, int n) {
    int i,j;
    for(i=0; i<m; i++) {
        for(j=0;j<n;j++) {
            printf("%f\t",float_abs(A[i][j]));
        }
        printf("\n");
    }
    printf("\n");
    return;
}

void print_vector(double *A, int n) {
    int i;
    for(i=0; i<n; i++) {
        printf("%f\n",A[i]);
    }
    printf("\n");
    return;
}

void print_vector_int(int *A, int n) {
    int i;
    for(i=0; i<n; i++) {
        printf("%i\n",A[i]);
    }
    printf("\n");
    return;
}

void set_matrix_zero(double **matrix_A, int n, int m) {

	int i,j;

	for (i = 0; i<n; i++) {
			for (j = 0; j<m; j++) {
				matrix_A[i][j] = 0;
			}
		}
}

double **PU_one(double **U, double **P, int m, int k, int iter){

	double **ret;
	int i,j;

	if(!(ret = matrix_smartinit(m,k))) return NULL;
	set_matrix_zero(ret, m, k);
	for (i=0; i<m; i++) {
		if (!(P[iter][i] < 10e-9)) {
			for (j=0; j<k; j++) {
				ret[i][j] = U[i][j];
			}
		}
	}
	return ret;
}

double **transpose_matrix(double **matrix_A, int n, int m) {
	/*
	 * Erstellt neue Matrix, in welche die Transponierte der Input Matrix geschrieben wird.
	 * Koennte durch "In-place"-Transposition ersetzt werden, da im Verfahren die Input Matrix nicht weiter gebraucht wird
	 */
	int i,j;
	double **tmp;

	tmp = matrix_smartinit(m, n);

	for (i=0; i<n; i++) {
		for (j=0; j<m; j++) {
			tmp[j][i] = matrix_A[i][j];
		}
	}
	return tmp;
}

void matrix_vector_multiply(double **A, double *x, double *b, int m, int n) {
    /*
     *Multiply matrix A (m*n) with vector x (n*1)
     */
    int i,j;
    double tmp;

    for(i=0;i<m;i++) {
        tmp = 0;
        for(j=0;j<n; j++) {
            tmp += A[i][j]*x[j];
        }
        b[i] = tmp;
    }
    return;
}
    
void matrix_multiply(double **A, double **B, double **C, int n, int m, int p) {
	/*
	 * Multiply matrix A (n*m) with matrix B (m*p)
	 */

	int i,j,k;
	double tmp;

	for(i=0; i<n; i++) {
		for(j=0; j<p; j++) {
			tmp = 0;
			for (k=0; k<m; k++) {
				tmp += A[i][k] * B[k][j];
			}
			C[i][j] = tmp;
		}
	}
	return;
}

void buid_AAU (double **PU, double eps, double *diag, int n) {
	/*
	 * Erstellt die Matrix AAU nach der Formel AAU = diag(sinv) * eps^(-1)*PU und schreibt sie in die nicht mehr
	 * benoetigte Matrix PU.
	 */

	int i,j;
	for (i=0; i<n; i++) {
		for (j=0; j<n; j++) {
			PU[i][j] *= 1.0/eps;
			if (i==j) PU[i][i] += diag[i];
		}
	}
}

void vector_double_division(double *final, double eps, int m) {
    int i;
    for (i=0; i<m; i++) final[i] /= eps;  
}


void LR_matrix_pivot(double **A, int n, int *perm, int iter) {

    int i,j,k;
    int tmp, tmp_perm;
	double test_j,test_tmp;
    for (i=0; i<n; i++) {

//           if(iter == 48) print_vector_int(perm, n);
     
		//Search for the larges value and switch rows accoringly
		tmp = i;
        tmp_perm = perm[i];
        
        test_tmp = A[perm[tmp]][i];
        for (k=0;k<i;k++) {
            test_tmp -= A[perm[tmp]][k] * A[perm[k]][tmp];
        }
        
		for (j=i+1; j<n; j++) {
            
            test_j = A[perm[j]][i];
            for (k=0;k<i;k++) {
                test_j -= A[perm[j]][k] * A[perm[k]][i];
            }
            
            if (float_abs(test_j) > float_abs(test_tmp)) {
            tmp = j;
            test_tmp = test_j;
            }
           
//			if (float_abs(A[perm[j]][i] > float_abs(A[perm[tmp]][i]))) tmp = j;
		}
       
        perm[i] = perm[tmp];
        perm[tmp] = tmp_perm;
        
		// Check if diagonal element doesn't equal zero
//		if(A[perm[i]][i] <= 10e-13 && A[perm[i]][i] >= -10e-13 ) break;
		if(test_tmp <= 10e-13 && test_tmp >= -10e-13 ) break;

//        if (iter == 48) printf("A[%i][%i] = %f\n", perm[i],i, A[perm[i]][i]);
//        if (iter == 48) printf("%f\n", test_tmp);
//        if(iter == 48) print_vector_int(perm, n);
        
		//Build upper rectangular matrix
		for (j=i; j<n; j++) {
			for(k=0; k<i; k++) {
				A[perm[i]][j] -= A[perm[i]][k] * A[perm[k]][j];
//               if (iter == 48 && perm[i] == 4 && j == 1) printf("A[%i][%i] = %f\t", perm[i],j, A[perm[i]][j]);
//               if (iter == 48 && perm[i] == 4 && j == 1) printf("A[%i][%i] = %f\t", perm[i],k, A[perm[i]][k]);
//               if (iter == 48 && perm[i] == 4 && j == 1) printf("A[%i][%i] = %f\n", perm[k],j, A[perm[k]][j]);
			}
		}

		//Build lower rectangular matrix
		for (j=i+1; j<n; j++) {
			for (k=0; k<i; k++) {
				A[perm[j]][i] -= A[perm[j]][k] * A[perm[k]][i];
//               if (iter == 48) {printf("A[%i][%i] = %f\t", perm[j],i, A[perm[j]][i]); printf("A[%i][%i] = %f\t", perm[j],k, A[perm[j]][k]); printf("A[%i][%i] = %f\n", perm[k],i, A[perm[k]][i]);}

			}
		    A[perm[j]][i] /= A[perm[i]][i];
//            if (iter == 48) printf("A[%i][%i] = %f\n", perm[j],i, A[perm[j]][i]);
//            if (iter == 48) printf("A[%i][%i] = %f\n", perm[i],i, A[perm[i]][i]);

		}  
	}

}

double *solve_A(double **A, double **b, int n, int iter) {
	
    double *ret;
	int *perm;
	int i,j;

    // Initialize solution vector
	if (!(ret = malloc(n*sizeof(double)))) return NULL;
	for(i=0;i<n;i++) ret[i] = 0;

    // Initialize permutaion vector

	if (!(perm = malloc(n*sizeof(int)))) return NULL;
	for (i=0; i<n; i++){
		perm[i] = i;
        
    }
//if(iter == 47) print_matrix(A, n, n); 
//    printf("ITERATION NR. %i\n\n", iter);   
//    print_matrix(A,n,n);
	//Decompose A into upper and lower rectangular matrix.
	LR_matrix_pivot(A, n, perm, iter);
//if(iter == 48) print_matrix(A, n, n);       
	//Solve L*y = b
	for (i=0; i<n; i++) {
		ret[i] = b[iter][perm[i]];
		for(j=0;j<i; j++) {
//			printf("ret[%i] = %f\tA[%i][%i] = %f\tret[%i] = %f\n", i, ret[i],perm[i],j,A[perm[i]][j], j, ret[j]);
			ret[i] -= (A[perm[i]][j]*ret[j]);
		}
	}
	//Solve R*x = y
	for (i=n-1; i>=0; i--) {
		for (j=n-1; j>i; j--){
			ret[i] -= A[perm[i]][j]*ret[j];
		}
		if(A[perm[i]][i] <= 10e-13 && A[perm[i]][i] >= -10e-13) ret[i] = 0;
		else ret[i] = ret[i]/A[perm[i]][i];
	}
	free(perm);
	return ret;
}
/*
int main() {


	return 0;
}
*/



void mexFunction (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {

	/*
	 * Check if In- and Output are correct
	 */
    
	int i,j;
	int n,m,k;
	double *eigenvectors;
	double *positions;
	double *sigmainv;
	double eps;
	double *z_matrix;
	double *result;
	double **P; //save P directly transposed
	double **Ut;
	double **Z; //save Z directly transposed
	double **U;
	double **PU1;
	double **PU;
	double *ret;
    double *final;

    
	if(nrhs < 5)
		mexErrMsgTxt("Too few Arguments. Must have five");
	if(nrhs > 5)
		mexErrMsgTxt("Too many Arguments. Must have five");
	if(nlhs != 1)
		mexErrMsgTxt("Function has only one output.");

	for (i=0; i<5; i++) {
		if( mxIsComplex(prhs[i]) || mxIsClass(prhs[i], "sparse") || mxIsChar(prhs[i]) )
			mexErrMsgTxt("Input must be real, full and nonstring");
	}

	n = mxGetN(prhs[1]);
	m = mxGetM(prhs[0]);
	k = mxGetN(prhs[0]);

	// Check if dimensions match
    if(mxGetM(prhs[1]) != m) mexErrMsgTxt("Dimensions of Argument 1 and Argument 2 do not match");
	if(mxGetM(prhs[2]) != k) mexErrMsgTxt("Dimensions of Argument 1 and Argument 3 do not match");
	if(mxGetM(prhs[3]) * mxGetN(prhs[3]) != 1) mexErrMsgTxt("Argument 4 has to be a scalar");
	if(mxGetM(prhs[4]) != k) mexErrMsgTxt("Dimensions of Argument 1 and Argument 4 do not match");
	if(mxGetN(prhs[4]) != n) mexErrMsgTxt("Dimensions of Argument 2 and Argument 4 do not match");

	/*
	 * Initialization
	 */



	eigenvectors = mxGetPr(prhs[0]);

	positions = mxGetPr(prhs[1]);

	sigmainv = mxGetPr(prhs[2]);

	eps = mxGetScalar(prhs[3]);

	z_matrix = mxGetPr(prhs[4]);

	plhs[0] = mxCreateDoubleMatrix(m, n, mxREAL);
	result = mxGetPr(plhs[0]);
    //save P directly transposed
	if (!(P = matrix_smartinit(n,m))) mexErrMsgTxt("Not enough Memory!");
	for (i=0; i<n; i++) {
		for(j=0; j<m; j++) {
			P[i][j] = positions[i*m +j];
		}
	}

	if (!(Ut = matrix_smartinit(k, m))) mexErrMsgTxt("Not enough Memory!");
	for (i=0; i<k; i++) {
		for (j=0; j<m; j++) {
			Ut[i][j] = eigenvectors[i*m +j];
		}
	}
    //save Z directly transposed
	if (!(Z = matrix_smartinit(n, k))) mexErrMsgTxt("Not enough Memory!");
	for (i=0; i<n; i++) {
		for (j=0; j<k; j++) {
			Z[i][j] = z_matrix[i*k +j];
		}
	}

    
//	if(!(ret=malloc(k*sizeof(double)))) mexErrMsgTxt("Not enough Memory!");
	if(!(U = transpose_matrix(Ut, k, m))) mexErrMsgTxt("Not enough Memory!");
    if(!(PU = matrix_smartinit(k,k))) mexErrMsgTxt("Not enough Memory!");
    if(!(final = malloc(m*sizeof(double)))) mexErrMsgTxt("Not enough Memory!");

	/*
	 * Calculation
	 */
	for(i=0; i<n; i++) {

		PU1 = PU_one(U, P, m, k, i);
//            if(i == 0) print_matrix(PU1, m, k);
        matrix_multiply(Ut, PU1, PU, k, m, k);
//            if(i == 0) print_matrix(PU, k, k);      
        buid_AAU (PU, eps, sigmainv,  k);
//            if(i == 0) print_matrix(PU, k, k);
        ret = solve_A(PU, Z, k, i);
//           if(i == 1) print_vector(ret, k);

        matrix_vector_multiply(PU1, ret, final, m, k); 
//            if(i == 0) print_vector(final, m);
        
        vector_double_division(final, eps, m);

        for (j=0; j<m; j++) {
			*(result +i*m + j) = final[j];
		}
        free(PU1);
        free(ret);
	}
	free(PU);
//	free(PU1);
	free(U);
	free(Ut);
	free(Z);
	free(P);
    free(final);



}
